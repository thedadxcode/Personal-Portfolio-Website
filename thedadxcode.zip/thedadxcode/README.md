# vCard - Personal portfolio

## Run this website

Hit **Run** up there, or just hit `Cmd + ENTER`!

You can customize it. Start from `index.html`.

## Author & License

This template has been developed by [@codewithsadee](https://www.twitter.com/codewithsadee). If you want to contact the author, you can reach out on [Twitter](https://www.twitter.com/codewithsadee). 

Donations: [Patreon](https://patreon.com/codewithsadee).

License: MIT (see LICENSE file).